#ifndef CONSTS_HW_H
#define CONSTS_HW_H

#include <stdint.h>
#include "../params.h"

extern const data_t zetas_barrett_hw[85][3];

#endif
