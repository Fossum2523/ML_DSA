/*
 * scutimer.h
 *
 *  Created on: 2015��10��29��
 *      Author: fac
 */

#ifndef SCUTIMER_H_
#define SCUTIMER_H_
#include "xscutimer.h"

void scutimer_start();
int scutimer_result();

#endif /* SCUTIMER_H_ */
