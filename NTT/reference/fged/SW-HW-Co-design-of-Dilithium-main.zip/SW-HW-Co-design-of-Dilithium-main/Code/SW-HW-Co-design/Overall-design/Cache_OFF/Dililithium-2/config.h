#ifndef CONFIG_H
#define CONFIG_H

#define DILITHIUM_MODE 2

#define CRYPTO_ALGNAME "Dilithium2"
#define DILITHIUM_NAMESPACE(s) pqcrystals_dilithium2_ref##s

#endif
